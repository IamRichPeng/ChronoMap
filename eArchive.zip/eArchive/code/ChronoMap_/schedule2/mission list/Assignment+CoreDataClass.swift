//written by: Ruicheng Peng
//tested by: Ruicheng Peng
//debugged by: Ruicheng Peng

import UIKit
import CoreData

@objc(Assignment)
public class Assignment: NSManagedObject {
    convenience init?(name: String?, time: Double, priority: String?) {
        let appDelegate = UIApplication.shared.delegate as? AppDelegate
        guard  let managedContext = appDelegate?.persistentContainer.viewContext else{
            return nil
        }
        
        self.init(entity: Assignment.entity(), insertInto: managedContext)
        
        self.name = name
        self.time = time
        self.priority = priority
    }
}
