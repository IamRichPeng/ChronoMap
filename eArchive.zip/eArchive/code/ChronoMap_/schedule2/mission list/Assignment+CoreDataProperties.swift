//written by: Ruicheng Peng
//tested by: Ruicheng Peng
//debugged by: Ruicheng Peng

import Foundation
import CoreData


extension Assignment {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Assignment> {
        return NSFetchRequest<Assignment>(entityName: "Assignment")
    }

    @NSManaged public var name: String?
    @NSManaged public var time: Double
    @NSManaged public var priority: String?

}
