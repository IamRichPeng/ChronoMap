//written by: Haofan Cui
//tested by: Haofan Cui
//debugged by: Haofan Cui


import UIKit
import CoreData

@objc(Entity)
public class Entity: NSManagedObject {
    convenience init?(property: Double?){
        let appDelegate = UIApplication.shared.delegate as? AppDelegate
        guard let managedContext = appDelegate?.persistentContainer.viewContext
            else {
                return nil
        }
        self.init(entity: Entity.entity(), insertInto: managedContext)
        self.property = property!
    }
    convenience init?(reward: Double?){
        let appDelegate = UIApplication.shared.delegate as? AppDelegate
        guard let manegedContext1 = appDelegate?.persistentContainer.viewContext
            else {
                return nil
        }
        self.init(entity: Entity.entity(), insertInto: manegedContext1)
        self.reward = reward!
    }
    
}
