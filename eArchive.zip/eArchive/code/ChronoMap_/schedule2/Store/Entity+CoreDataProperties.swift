//written by: Haofan Cui
//tested by: Haofan Cui
//debugged by: Haofan Cui

import Foundation
import CoreData


extension Entity {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Entity> {
        return NSFetchRequest<Entity>(entityName: "Entity")
    }

    @NSManaged public var property: Double
    @NSManaged public var reward: Double

}
