-----------------Special notes-------------------

The source code submit in FinalSubmit is slightly different from Report3 in class diagrams and function, variable names.
We have talked to professor Wei about this situation and he said we should point it out to avoid to much deduction.


Reason: 
	1.The source code of iOS interface are sort out by compiler into class, where each controller correspond to one .swift file. And each controller is a big class, which cause the inconsistency between report and code.

	2.The library functions' name are all fixed. When we create the UML class, we did not finishing coding everything. Therefore, we did not know the exact functions' name before we tried to implement the functions shown in report. 
	
	3.Because the name of '.swift' file will interactive with other files, the name can't be changed, otherwise all the source code need to be changed. What's more, for the season that when we finish our Report 3, the source code hadn't been neat finished yet, some library function name is not correct. We can't change the name of Xcode library functions. 
	4. Overall, Swift is not a traditional object-oriented language and we are also new to it. We keep learning new things while implementing the project and try to follow the incremental development during the whole project. Although some parts are unperfected and inconsistent with UML, we are happy with what we done.
        The correspond of screen interface to swift source code is generate by compiler, so that some of the variable name might be different from Report 3.
Despite this, the functions achieved are all the same. 